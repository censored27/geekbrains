package GeekBrainsHW5;

//import ru.geekbrains.lesson_e.online.Animal;

public final class Cat extends Animal {

    //protected int runlength;
    //runlength = 200

    public Cat(int age, String color, String name) {
        super(age, color, name);
        this.runlength = 200;
    }

//    @Override
//    public void voice() {
//        System.out.println(name + " meows");
//  }

}
