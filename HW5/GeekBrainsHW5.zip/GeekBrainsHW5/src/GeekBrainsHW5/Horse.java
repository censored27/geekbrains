package GeekBrainsHW5;

//import ru.geekbrains.lesson_e.online.Animal;

public class Horse extends Animal {
    public Horse(int age, String color, String name) {
        super(age, color, name);
        this.runlength = 1500;
    }

}
